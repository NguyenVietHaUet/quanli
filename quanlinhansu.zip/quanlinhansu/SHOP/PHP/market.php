<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome</title>
	<link rel="stylesheet" type="text/css" href="../CSS/market.css">
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="row text-center">
			<div class="col-sm-12" style="margin-top: 50px;">
					<img src="../IMAGE/logoch.png">
				</div>
		</div>
		<div class="row text-center">
			<div class="col-md-12" style=" margin-top: 120px;">
				<button class="btn btn-secondary" style="width: 300px;"><a href="http://localhost:8080/quanlinhansu/login/index.php" style="color: white; font-size: 22px;">Quản lý</a></button>
			</div>
		</div>
		<div class="row text-center" style="margin-top: 60px;">
			<div class="col-md-12">
				<button class="btn btn-secondary" style="width: 300px;"><a href="signin.php" style="color: white; font-size: 22px;">Nhân viên</a></button>
			</div>
		</div>
	</div>
</body>
</html>