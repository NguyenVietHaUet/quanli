<?php
  session_start();
  if(isset($_SESSION['username'])) {
  	unset($_SESSION['username']);
  	header('location:http://localhost:8080/quanlinhansu/shop/php/market.php');
  }
  else {
  	header('location:http://localhost:8080/quanlinhansu/shop/php/market.php');
  }
?>