<?php
	session_start();
	if(isset($_SESSION['username']))
	{
		header('location: Trangchu.php');
	}
	else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sign in</title>
	<link rel="stylesheet" type="text/css" href="../CSS/signin.css">
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="row text-center" style="height: 300px; padding-top: 60px;">
			<div class="col-md-12" style="font-family: cursive;">
				<p>WELCOME TO OUR APPLICATION</p>
				<img src="../IMAGE/logoch.png">
				<p>Let's login your account!!!</p>
			</div>
		</div>
		<div class="row text-center" style="height: 300px;">
			<div class="col-md-12" style="font-family: cursive;">
				<form method="POST" class="was-validated">
					<div class="form-group">
						<label for="">Username</label>
						<input class="rounded-sm" type="text" name="username" placeholder="Your username" required>
					</div>
					<div class="form-group">
						<label for="">Password</label>
						<input class="rounded-sm" id="pw" type="password" name="txtpassword" minlength="6" placeholder="Your password" required>
					</div>
					<div class="form-group form-check">
						<label class="form-check-label">
						<input class="form-check-input rounded-sm" type="checkbox"> Remember me
						</label>
					</div>
					<input  class="btn btn-secondary" type="submit" name="btnsubmit" value="Sign in">
					<div class="form-group">
					<br>
						<label>You don't have an account?</label>
						<a href="http://localhost:8080/quanlinhansu/SHOP/PHP/Signup.php" class="text-secondary">Sign up</a>
					</div>
				</form>
			</div>
		</div>
		<div class="row text-center" style="height: 200px;">
			<div class="col-md-12" style="font-family: cursive;">
				<?php
					$con = mysqli_connect('127.0.0.1', 'root', '', '_user');
					if(isset($_POST['btnsubmit']))
					{
						$username = $_POST['username'];
						$password = $_POST['txtpassword'];
						$sql = "SELECT * FROM person WHERE username = N'$username'  AND pass = '$password'";
						$query = mysqli_query($con, $sql);
						$num = mysqli_num_rows($query);
						if($num > 0)
						{  	     
							$_SESSION['username'] = $username;
							header('location:trangchu.php');
						}
						else {
							echo '<p class="text-danger">Username or password is incorrect</p>';
							header("refresh:5 url=http://localhost:8080/quanlinhansu/SHOP/PHP/signin.php");
						}
					}
				?>
			</div>
		</div>
	</div>
</body>
</html>
<?php
	};
?>